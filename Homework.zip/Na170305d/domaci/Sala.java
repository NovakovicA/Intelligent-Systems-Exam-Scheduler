package domaci;

public class Sala implements Comparable<Sala>{
	private String naziv;
	private int kapacitet;
	private int imaRacunare;
	private int brDezurnih;
	private int fakultet;
	
	
	
	public Sala(String naziv, int kapacitet, int imaRacunare, int brDezurnih, int fakultet)  {
		super();
		this.naziv = naziv;
		this.kapacitet = kapacitet;
		this.imaRacunare = imaRacunare;
		this.brDezurnih = brDezurnih;
		this.fakultet = fakultet;
	}
	
	public String getNaziv() {
		return naziv;
	}
	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}
	public int getKapacitet() {
		return kapacitet;
	}
	public void setKapacitet(int kapacitet) {
		this.kapacitet = kapacitet;
	}
	public int getImaRacunare() {
		return imaRacunare;
	}
	public void setImaRacunare(int imaRacunare) {
		this.imaRacunare = imaRacunare;
	}
	public int getBrDezurnih() {
		return brDezurnih;
	}
	public void setBrDezurnih(int brDezurnih) {
		this.brDezurnih = brDezurnih;
	}
	public int getFakultet() {
		return fakultet;
	}
	public void setFakultet(int fakultet) {
		this.fakultet = fakultet;
	}

	@Override
	public String toString() {
		return "Sala [naziv=" + naziv + ", kapacitet=" + kapacitet + ", imaRacunare=" + imaRacunare + ", brDezurnih="
				+ brDezurnih + ", fakultet=" + fakultet + "]";
	}

	@Override
	public int compareTo(Sala o) {
		if( (o.getKapacitet()/(o.getBrDezurnih() + (o.getFakultet()==1?0:1.2)) ) < (this.getKapacitet()/(this.getBrDezurnih() + (this.getFakultet()==1?0:1.2)) )) return 1;
		else return -1;
	}
	
	
	
	

}
