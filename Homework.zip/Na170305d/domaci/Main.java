package domaci;

import java.util.LinkedList;
import java.util.List;
import java.nio.file.*;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import org.json.*;

public class Main {
	private static String inputRok="javni_testovi/rok5.json";
	private static String inputSale="javni_testovi/sale5.json";
	private static String outputFile = "javni_testovi/out5.csv";
	
	private static boolean showbrojBodova=true;
	private static double brojBodova=0;
	
	private static JSONArray rokoviJSON;
	private static JSONArray saleJSON;
	
	private static int trajanjeRoka=0;
	private static List<Ispit> ispiti=new LinkedList<Ispit>();
	private static List<Sala> sale=new LinkedList<Sala>();
	
	public static void  main(String[] args) throws IOException{
		
		 Path putanja = Paths.get(inputRok);
	     List < String > linije = Files.readAllLines(putanja, StandardCharsets.UTF_8);
	     String sadrzaj=String.join(System.lineSeparator(), linije);
	     
	     trajanjeRoka=(new JSONObject(sadrzaj.toString())).getInt("trajanje_u_danima");
	     
	     rokoviJSON=(new JSONObject(sadrzaj.toString())).getJSONArray("ispiti");
	     
	     for (int i=0; i < rokoviJSON.length(); i++) {
	    	List<String> temp=new LinkedList<String>();
	    	JSONArray smerovi = (JSONArray) rokoviJSON.getJSONObject(i).get("odseci");
	    	for(int j=0;j<smerovi.length();j++) temp.add(smerovi.getString(j));
	    	
	    	ispiti.add(new Ispit(rokoviJSON.getJSONObject(i).getString("sifra"),rokoviJSON.getJSONObject(i).getInt("prijavljeni"),
	    	rokoviJSON.getJSONObject(i).getInt("racunari"),temp));
	    	}
	     
	     
		 putanja = Paths.get(inputSale);
	     linije = Files.readAllLines(putanja, StandardCharsets.UTF_8);
	     sadrzaj=String.join(System.lineSeparator(), linije);
	     
	     saleJSON=(new JSONArray(sadrzaj.toString()));
	     
	     for (int i=0; i < saleJSON.length(); i++) {
	    	 sale.add(new Sala(saleJSON.getJSONObject(i).getString("naziv"),saleJSON.getJSONObject(i).getInt("kapacitet"),saleJSON.getJSONObject(i).getInt("racunari"),
	    			 saleJSON.getJSONObject(i).getInt("dezurni"),saleJSON.getJSONObject(i).getInt("etf")));
	    	}
	     
	     Algoritam algo = new Algoritam(trajanjeRoka,ispiti,sale);
	     
	     int result = algo.run();
	     PrintStream izlaz = new PrintStream(new FileOutputStream(outputFile), true, "UTF-8");
	     if(result==-1) {
	    	 izlaz.println("Nije moguce napraviti raspored za dati rok.");
	     }
	     
	     else {
	     for(int i=1;i<trajanjeRoka+1;i++) {
	    	 izlaz.print("Dan" + i);
	    	 for(int j=0;j<sale.size();j++) {
	    		 izlaz.print("," + sale.get(j).getNaziv());
	    	 }
	    	 izlaz.println("");
	    	 
	    	 for(int k=1;k<5;k++) { 
	    		 switch(k) {
	    		 case 1: izlaz.print("08:00"); break;
	    		 case 2: izlaz.print("11:30"); break;
	    		 case 3: izlaz.print("15:00"); break;
	    		 case 4: izlaz.print("18:30"); break;}
	    		 
	    		 for(int j=0;j<sale.size();j++) {
	    		 Sala s=sale.get(j); boolean found=false;
	    		 for(int m=0;m<ispiti.size();m++) if(ispiti.get(m).getDan()==i && ispiti.get(m).getTermin()==k && ispiti.get(m).getSale().contains(s)) {found=true; izlaz.print("," + ispiti.get(m).getSifra());}
	    		 if(!found) izlaz.print(",X");
	    		 else {
	    			 brojBodova+=s.getBrDezurnih();
	    			if(s.getFakultet()!=1) brojBodova+=1.2;
	    		 }
	    		 }
	    		 if(i==trajanjeRoka && k==4);
	    		 else izlaz.println("");
	    	 }
	    	if(i!=trajanjeRoka) izlaz.println("");
	     }
	     }
	     izlaz.close();
	     if(showbrojBodova) System.out.println("Broj bodova za generisani raspored: " + brojBodova);
	}
	
	
	
}
