package domaci;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class Algoritam {
	
	private int trajanjeRoka;
	private List<Ispit> ispiti;
	private List<Sala> sale;
	
	private static boolean saveLog=true;
	private static String logFile = "javni_testovi/log1.txt";
	
	
	public Algoritam(int trajanjeRoka,List<Ispit> ispiti, List<Sala> sale) {
		super();
		this.ispiti = ispiti;
		this.sale = sale;
		this.trajanjeRoka=trajanjeRoka;
	}
	
	
	public int run() throws UnsupportedEncodingException, FileNotFoundException {
		int ret=0;
		if(trajanjeRoka<1) return -1;
		PrintStream izlaz=new PrintStream(new FileOutputStream(logFile), true, "UTF-8");
		if(!saveLog) izlaz.close();
		
		Ispit ispit=null; List<Sala> dostupneSale=new LinkedList<Sala>();
		List<String> ogr_dan=new LinkedList<String>();
		List<String> ogr_termin=new LinkedList<String>();
		for(int trenutniDan=1;trenutniDan<trajanjeRoka+1;trenutniDan++) {
		for(int termin=1;termin<5;termin++) {
			sale.forEach(s->dostupneSale.add(s));
			ispit=uzmiSledeci(dostupneSale,ogr_dan,ogr_termin);
			while(ispit!=null) {
				ispit.setDan(trenutniDan); ispit.setTermin(termin);
				ispit.setSale(nadjiSaleZaIspit(ispit, dostupneSale));
				for(int i=0;i<ispit.getSmerovi().size();i++) ogr_dan.add(ispit.getSmerovi().get(i) + "" + ispit.getGodina());
				for(int i=0;i<ispit.getSmerovi().size();i++) ogr_termin.add(ispit.getSmerovi().get(i) + "" + ispit.getGodina());
				ispit=uzmiSledeci(dostupneSale,ogr_dan,ogr_termin);
			}
			dostupneSale.clear();
			ogr_termin.clear();
		}
		ogr_dan.clear();
		}
		if(saveLog) izlaz.println("-----------------------------------------------");
		if(saveLog) izlaz.println("Prvobitno generisan raspored: ");
		if(saveLog) izlaz.println(ispiti.toString());
		if(saveLog) izlaz.println("-----------------------------------------------");
		
		if(postojeNerasporedjeniIspiti()) {if(saveLog) izlaz.close(); return -1;}
		
		
		boolean postojiPromena=true;
		
	
		while(postojiPromena) {
			postojiPromena=false;
			for(int i=0;i<ispiti.size();i++) {
				ispit=ispiti.get(i);
				List<Sala> dos=dohvatiDostupneSale(sale, ispit.getDan(), ispit.getTermin(), ispiti);
				for(int j=0;j<dos.size();j++) for(int k=0;k<ispit.getSale().size();k++) 
					if(dos.get(j).getImaRacunare()==ispit.getSale().get(k).getImaRacunare() && dos.get(j).getKapacitet()>ispit.getSale().get(k).getKapacitet() ){
					double cena1 = dos.get(j).getBrDezurnih() + (dos.get(j).getFakultet()==1?0:1.2);
					double cena2 = ispit.getSale().get(k).getBrDezurnih() + (ispit.getSale().get(k).getFakultet()==1?0:1.2);
					if(cena1<cena2) {
						ispit.getSale().remove(k); ispit.getSale().add(dos.get(j));
						if(saveLog) izlaz.println("Ispit je zamenio salu u okviru svog termina: ");
						if(saveLog) izlaz.println(ispit.toString());
						if(saveLog) izlaz.println("-----------------------------------------------");
						postojiPromena=true;
					}}}
			
			for(int i=0;i<ispiti.size();i++) {
				ispit=ispiti.get(i);
			for(int j=ispit.getDan();j<trajanjeRoka+1;j++)
				{
				ogr_dan.clear();
				for(int k=0;k<ispiti.size();k++) if(ispiti.get(k).getDan()==j) for(int l=0;l<ispiti.get(k).getSmerovi().size();l++) ogr_dan.add(ispiti.get(k).getSmerovi().get(l) + "" + ispiti.get(k).getGodina());
				if(ispit.getDan()==j)  for(int k=0;k<ispit.getSmerovi().size();k++)  ogr_dan.remove(ispit.getSmerovi().get(k)+ "" + ispit.getGodina());
				
				for (int k=(ispit.getDan()==j?ispit.getTermin():1);k<5;k++) {
				ogr_termin.clear();
				for(int m=0;m<ispiti.size();m++) if(ispiti.get(m).getTermin()==k && ispiti.get(m).getDan()==j) for(int l=0;l<ispiti.get(m).getSmerovi().size();l++) ogr_termin.add(ispiti.get(m).getSmerovi().get(l) + "" + ispiti.get(m).getGodina());
				List<Sala> dos=dohvatiDostupneSale(sale, j, k, ispiti);
				if(brSlobodnihMesta(dos,ispit.getNaRacunarima()) > ispit.getBrojStudenata() && zadovoljavaOgranicenja(ispit, ogr_dan, ogr_termin))
				{
				List<Sala> nove=nadjiNajboljeSaleZaIspit(ispit, dos);
					if(getBrPoena(nove)<getBrPoena(ispit.getSale())){
					ispit.setSale(nove);
					ispit.setDan(j); ispit.setTermin(k);
					if(saveLog) izlaz.println("Ispit je dobio nov dan/termin i sale: ");
					if(saveLog) izlaz.println(ispit.toString());
					if(saveLog) izlaz.println("-----------------------------------------------");
					postojiPromena=true;
				}}
					}
				}
			}
		}
		if(saveLog) izlaz.close();
		return ret;
	}
	
	
	private Ispit uzmiSledeci(List<Sala> dostupneSale,List<String> ogr_dan,List<String> ogr_termin) {
		Ispit ret=null;
		Ispit ispit=null;
		for (int i = 0; i < ispiti.size(); i++) {
            ispit=ispiti.get(i);
            if(ispit.getDan()==0 && brSlobodnihMesta(dostupneSale,ispit.getNaRacunarima())>=ispit.getBrojStudenata() && zadovoljavaOgranicenja(ispit,ogr_dan,ogr_termin))  {
				if(ret==null) ret=ispit;
				else if(ispit.getSmerovi().size()>ret.getSmerovi().size()) {ret=ispit;}
				else if(ispit.getSmerovi().size()==ret.getSmerovi().size() && ispit.getBrojStudenata()>ret.getBrojStudenata()) {ret=ispit;}
				else if(ispit.getSmerovi().size()==ret.getSmerovi().size() && ispit.getBrojStudenata()==ret.getBrojStudenata()
						&& ispit.getNaRacunarima()<ret.getNaRacunarima()) {ret=ispit;}
			}
        }
		return ret;
	}
	
	private boolean zadovoljavaOgranicenja(Ispit ispit,List<String> ogr_dan,List<String> ogr_termin) {
		for(int i=0;i<ispit.getSmerovi().size();i++) {
			if(ogr_dan.contains(ispit.getSmerovi().get(i) + ispit.getGodina())) {return false;}
			if(ogr_termin.contains(ispit.getSmerovi().get(i) + (ispit.getGodina()+1))) return false;
			if(ogr_termin.contains(ispit.getSmerovi().get(i) + (ispit.getGodina()-1))) return false;
		}
		return true;
	}
	
	
	private int brSlobodnihMesta(List<Sala> dostupneSale, int racunari) {
		int ret=0;
		for (int i = 0; i < dostupneSale.size(); i++) {
			Sala s=dostupneSale.get(i);
			if(s.getImaRacunare()==racunari) ret+=s.getKapacitet();
		}
		return ret;
	}
	
	
	private boolean postojeNerasporedjeniIspiti() {
		Ispit ispit=null;
		for (int i = 0; i < ispiti.size(); i++) {
            ispit=ispiti.get(i);
            if(ispit.getDan()==0) {
            	return true;
            }
			}
		return false;
	}
	
	
	
	private List<Sala> nadjiSaleZaIspit(Ispit ispit, List<Sala> dostupneSale){
		List<Sala> saleret = new LinkedList<Sala>();
		Sala min_zad=null,max=null;
		for(int i=0;i<dostupneSale.size();i++) {
			Sala s=dostupneSale.get(i);
			if(max==null && s.getImaRacunare()==ispit.getNaRacunarima()) max=s;
			else if (max!=null) if (max.getKapacitet()<s.getKapacitet()) max=s;
			
			if(min_zad==null && s.getKapacitet()>=ispit.getBrojStudenata() && s.getImaRacunare()==ispit.getNaRacunarima()) min_zad= s;
			else if (min_zad!=null &&  s.getImaRacunare()==ispit.getNaRacunarima()) if(min_zad.getKapacitet()>s.getKapacitet() && s.getKapacitet()>=ispit.getBrojStudenata()) min_zad= s;
		}
		if(min_zad!=null) { saleret.add(min_zad); dostupneSale.remove(min_zad); return saleret;}
		else {
			saleret.add(max);
			dostupneSale.remove(max);
			
			while(brSlobodnihMesta(saleret,ispit.getNaRacunarima())<ispit.getBrojStudenata()) {
				max=null; min_zad=null;
				for(int i=0;i<dostupneSale.size();i++) {
					Sala s=dostupneSale.get(i);
					if(max==null && s.getImaRacunare()==ispit.getNaRacunarima()) max=s;
					else if (max!=null) if (max.getKapacitet()<s.getKapacitet()) max=s;
					
					if(min_zad==null && (s.getKapacitet()+brSlobodnihMesta(saleret,ispit.getNaRacunarima()))>ispit.getBrojStudenata() && s.getImaRacunare()==ispit.getNaRacunarima()) min_zad= s;
					else if (min_zad!=null &&  s.getImaRacunare()==ispit.getNaRacunarima()) if(min_zad.getKapacitet()>s.getKapacitet() && (s.getKapacitet()+brSlobodnihMesta(saleret,ispit.getNaRacunarima()))>ispit.getBrojStudenata()) min_zad= s;
				}
				
				if(min_zad!=null) { saleret.add(min_zad); dostupneSale.remove(min_zad); return saleret;}
				else {saleret.add(max); dostupneSale.remove(max);}
				}
			}
		return saleret;
	}
	
	private List<Sala> dohvatiDostupneSale(List<Sala> sale, int dan, int termin, List<Ispit> ispiti){
		List<Sala> ret = new LinkedList<Sala>();
		for(int i=0;i<sale.size();i++) ret.add(sale.get(i));
		for(int i=0;i<ispiti.size();i++) {
			Ispit ispit = ispiti.get(i);
			if(ispit.getDan()==dan && ispit.getTermin()==termin) for(int j=0;j<ispit.getSale().size();j++) ret.remove(ispit.getSale().get(j));
		}
		return ret;
	}
	
	
	private List<Sala> nadjiNajboljeSaleZaIspit(Ispit ispit, List<Sala> dostupneSale){
		List<Sala> saleret = new LinkedList<Sala>();
		Collections.sort(dostupneSale,Collections.reverseOrder());
		int brMesta=0;
		for(int i=0;i<dostupneSale.size();i++) {
			saleret.add(dostupneSale.get(i)); brMesta+=dostupneSale.get(i).getKapacitet(); 
			if(brMesta>=ispit.getBrojStudenata()) break;
			}
		return saleret;
	}
	
	
	double getBrPoena(List<Sala> sale){
		double ret=0;
		for(int i=0;i<sale.size();i++) ret+=sale.get(i).getBrDezurnih() + (sale.get(i).getFakultet()==1?0:1.2);
		return ret;
	}
	
}
