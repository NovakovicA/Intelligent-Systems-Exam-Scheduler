package domaci;

import java.util.LinkedList;
import java.util.List;

public class Ispit {
	private String sifra;
	private int brojStudenata;
	private int naRacunarima;
	private List<String> smerovi;
	
	private List<Sala> sale;
	private int dan;
	private int termin;
	
	public Ispit(String sifra, int brojStudenata, int naRacunarima, List<String> smerovi) {
		super();
		this.sifra = sifra;
		this.brojStudenata = brojStudenata;
		this.naRacunarima = naRacunarima;
		this.smerovi = smerovi;
		sale=new LinkedList<Sala>();
		dan=0;
		termin=0;
	}
	
	public String getSifra() {
		return sifra;
	}
	
	public void setSifra(String sifra) {
		this.sifra = sifra;
	}
	public int getBrojStudenata() {
		return brojStudenata;
	}
	public void setBrojStudenata(int brojStudenata) {
		this.brojStudenata = brojStudenata;
	}
	public int getNaRacunarima() {
		return naRacunarima;
	}
	public void setNaRacunarima(int naRacunarima) {
		this.naRacunarima = naRacunarima;
	}
	public List<String> getSmerovi() {
		return smerovi;
	}
	public void setSmerovi(List<String> smerovi) {
		this.smerovi = smerovi;
	}



	@Override
	public String toString() {
		return "Ispit [sifra=" + sifra + ", brojStudenata=" + brojStudenata + ", naRacunarima=" + naRacunarima
				+ ", smerovi=" + smerovi + ", sale=" + sale + ", dan=" + dan + ", termin=" + termin + "]";
	}

	public List<Sala> getSale() {
		return sale;
	}

	public void setSale(List<Sala> sale) {
		this.sale = sale;
	}

	public int getDan() {
		return dan;
	}

	public void setDan(int dan) {
		this.dan = dan;
	}

	public int getTermin() {
		return termin;
	}

	public void setTermin(int termin) {
		this.termin = termin;
	}
	
	public int getGodina() {
		return Character.getNumericValue(sifra.charAt(5));
	}
	
	

	

}
